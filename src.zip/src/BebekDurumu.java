public abstract class BebekDurumu {

}
