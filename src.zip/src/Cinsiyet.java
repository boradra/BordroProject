public enum Cinsiyet {
    ERKEK , KADIN
}
