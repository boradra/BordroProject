public class Servant implements Calisan {
    private String id;
    private String isim;
    private String soyisim;
    private Cinsiyet cinsiyet;
    private Cinsiyet cocukCinsiyet;
    private int brutMaas;
    private int avans;
    private int bebekAylık;
    private boolean hamilelikDurumu;
    private double sskPrim, gelirVergisi, netMaas;

    public Servant(String id, String isim, String soyisim, Cinsiyet cinsiyet, int brutMaas,
                   int avans, boolean hamilelikDurumu, Cinsiyet cocukCinsiyet, int bebekAylık) {
        this.id = id;
        this.isim = isim;
        this.soyisim = soyisim;
        this.cinsiyet = cinsiyet;
        this.brutMaas = brutMaas;
        this.avans = avans;
        this.hamilelikDurumu = hamilelikDurumu;
        this.cocukCinsiyet = cocukCinsiyet;
        this.bebekAylık = bebekAylık;
    }

    public Servant(Builder builder) {
        this.id = builder.id;
        this.isim = builder.isim;
        this.soyisim = builder.soyisim;
        this.cinsiyet = builder.cinsiyet;
        this.brutMaas = builder.brutMaas;
        this.avans = builder.avans;
        this.hamilelikDurumu = builder.hamilelikDurumu;
        this.cocukCinsiyet = builder.cocukCinsiyet;
        this.bebekAylık = builder.bebekAylık;
    }

    public static class Builder {
        private String id;
        private String isim;
        private String soyisim;
        private Cinsiyet cinsiyet;
        private Cinsiyet cocukCinsiyet;
        private int brutMaas;
        private int avans;
        private int bebekAylık;
        private boolean hamilelikDurumu;
        private double sskPrim, gelirVergisi, netMaas;

        public Builder(String id, String ad) {
            this.id = id;
            this.isim = ad;
        }

        public Builder isim(String isim) {
            this.isim = isim;
            return this;
        }

        public Builder soyİsim(String soyisim) {
            this.soyisim = soyisim;
            return this;
        }

        public Builder cinsiyet(Cinsiyet cinsiyet) {
            this.cinsiyet = cinsiyet;
            return this;
        }

        public Builder cocukCinsiyeti(Cinsiyet cocukCinsiyet) {
            this.cocukCinsiyet = cocukCinsiyet;
            return this;
        }

        public Builder brutMaas(int brutMaas) {
            this.brutMaas = brutMaas;
            return this;
        }

        public Builder avans(int avans) {
            this.avans = avans;
            return this;
        }

        public Builder hamilelikDurumu(boolean hamilelikDurumu) {
            this.hamilelikDurumu = hamilelikDurumu;
            return this;
        }

        public Builder cocukCinsiyeti(boolean cocukCinsiyeti) {
            this.cocukCinsiyet = cocukCinsiyet;
            return this;
        }

        public Builder bebekAylık(int bebekAylık) {
            this.bebekAylık = bebekAylık;
            return this;
        }

        public Servant build() {
            return new Servant(this);
        }
    }

    @Override
    public double MaasUygula() {
        return 0;
    }
}
