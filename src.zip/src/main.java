import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class main {
    static List<Calisan> calisanlar;

    static
    {
        try {
            calisanlar = dosyaOku();  //
        } catch (IOException e) {
            e.printStackTrace();
            calisanlar = new ArrayList<>();
        }
    }

    public static List<Calisan> dosyaOku() throws IOException {
        String csvPath = "C:\\Bordro_csv\\kullanicilar_unvan.csv";
        List<Calisan> calisanlar = new ArrayList<>();
        // senin oluşturduğun dosyanın yolu
        try (BufferedReader br = Files.newBufferedReader(Paths.get(csvPath))) {
            String line = br.readLine();             // ► başlık satırını alıp geçiyoruz
            while ((line = br.readLine()) != null) { // ► satır satır oku
                String[] cols = line.split(";", -1);
                String id        = cols[0];
                String ad        = cols[1];
                String soyad     = cols[2];
                int    brutMaas  = Integer.parseInt(cols[3]);
                Cinsiyet cinsiyet  = Cinsiyet.valueOf(cols[4]);
                int    avans     = Integer.parseInt(cols[5]);
                String unvan  = cols[6].toUpperCase();
                boolean hamile   = cols[7].equalsIgnoreCase("EVET");
                String cocukCinsiyeti = cols[8];
                int cocukAylık = Integer.parseInt(cols[9]);
                Calisan calisan = new CalisanFactory(id,ad,soyad,brutMaas,cinsiyet,avans,hamile,cocukCinsiyeti,cocukCinsiyeti,cocukAylık,unvan)
                System.out.printf("%s %s %s %s (%s): maaş=%d₺, avans=%d₺, hamile mi=%s \n",c.getId(),c.getAd(),c.getSoyad(),c.getCinsiyet(),c.getUnvan(),c.getBrutMaas(),c.getAvans(),c.isHamile());
                calisanlar.add(calisan);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return calisanlar;
    }

    public static void writeCSV(List<Calisan> calisanlar){
        String outputPath = "C:\\Bordro_csv\\maas_bilgileri6.csv";
        try(BufferedWriter bw = Files.newBufferedWriter(Paths.get(outputPath)))
        {
            bw.write("ID;AD;SOYAD;AVANS;SSK_Primi;Gelir_Vergisi;Net_Maas");
            bw.newLine();
            for(Calisan c:calisanlar)
            {
                bw.write(String.join(";", c.getId(), c.getAd(), c.getSoyad(),
                        String.format("%d",c.getAvans()),
                        String.format("%.2f", c.getSskPrim()),
                        String.format("%.2f", c.getGelirVergisi()),
                        String.format("%.2f", c.getNetMaas())));
                bw.newLine();
            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public static void main(String[] args)
    {
        List<MaasHesaplayıcıIF> kurallar = List.of(
                new SskVergisiKesintiKurali(), new HamilelikDurumuKurali(), new MaaşBonusUygula(), new GelirVergisiKesintiKurali(), new AvansUygula()
        );
        MaasKurallarınıUygula hesaplayici = new MaasKurallarınıUygula(kurallar);
        for(CalisanBilgisi c:calisanlar)
        {
            hesaplayici.hesapla(c);
        }
        writeCSV(calisanlar);
    }
}