public interface Calisan {
    double MaasUygula();
}
