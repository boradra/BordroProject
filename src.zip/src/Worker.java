public class Worker implements Calisan {
    // Özellikler
    private String id;
    private String isim;
    private String soyisim;
    private Cinsiyet cinsiyet;
    private Cinsiyet cocukCinsiyet;
    private int brutMaas;
    private int avans;
    private int bebekAylık;
    private boolean hamilelikDurumu;
    private double sskPrim, gelirVergisi, netMaas;

    // Yapıcılar (Constructor + Builder)
    public Worker(String id, String isim, String soyisim, Cinsiyet cinsiyet, int brutMaas, int avans, boolean hamilelikDurumu, Cinsiyet cocukCinsiyet, int bebekAylık) {
        this.id = id;
        this.isim = isim;
        this.soyisim = soyisim;
        this.cinsiyet = cinsiyet;
        this.brutMaas = brutMaas;
        this.avans = avans;
        this.hamilelikDurumu = hamilelikDurumu;
        this.cocukCinsiyet = cocukCinsiyet;
        this.bebekAylık = bebekAylık;
    }

    public Worker(Builder builder) {
        this.id = builder.id;
        this.isim = builder.isim;
        this.soyisim = builder.soyisim;
        this.cinsiyet = builder.cinsiyet;
        this.brutMaas = builder.brutMaas;
        this.avans = builder.avans;
        this.hamilelikDurumu = builder.hamilelikDurumu;
        this.cocukCinsiyet = builder.cocukCinsiyet;
        this.bebekAylık = builder.bebekAylık;
    }

    // --- Builder Sınıfı ---
    public static class Builder {
        private String id;
        private String isim;
        private String soyisim;
        private Cinsiyet cinsiyet;
        private Cinsiyet cocukCinsiyet;
        private int brutMaas;
        private int avans;
        private int bebekAylık;
        private boolean hamilelikDurumu;

        public Builder(String id, String ad) {
            this.id = id;
            this.isim = ad;
        }

        public Builder isim(String isim) { this.isim = isim; return this; }
        public Builder soyİsim(String soyisim) { this.soyisim = soyisim; return this; }
        public Builder cinsiyet(Cinsiyet cinsiyet) { this.cinsiyet = cinsiyet; return this; }
        public Builder cocukCinsiyeti(Cinsiyet cocukCinsiyet) { this.cocukCinsiyet = cocukCinsiyet; return this; }
        public Builder brutMaas(int brutMaas) { this.brutMaas = brutMaas; return this; }
        public Builder avans(int avans) { this.avans = avans; return this; }
        public Builder hamilelikDurumu(boolean hamilelikDurumu) { this.hamilelikDurumu = hamilelikDurumu; return this; }
        public Builder bebekAylık(int bebekAylık) { this.bebekAylık = bebekAylık; return this; }

        public Worker build() {
            return new Worker(this);
        }
    }

    // --- Maaş hesaplama metodu ---
    public double MaasUygula() {
        // 1. SSK Prim Oranı hesapla
        double sskOrani = getSskOrani();
        sskPrim = brutMaas * sskOrani;

        // 2. Gelir Vergisi Oranı hesapla
        double gelirVergiOrani = 0.20;
        if (cinsiyet == Cinsiyet.KADIN) {
            gelirVergiOrani -= 0.05; // Kadın WORKER'a %5 indirim
        }

        gelirVergisi = brutMaas * gelirVergiOrani;

        // 3. Ek ödemeler:
        int ekstra = 0;
        if (cinsiyet == Cinsiyet.KADIN) {
            ekstra += 100; // Kadın WORKER'a 100 TL
        }
        if (hamilelikDurumu) {
            ekstra += 300; // Hamile kadın WORKER'a 300 TL
        }

        // 4. Net maaş hesapla
        netMaas = brutMaas - sskPrim - gelirVergisi - avans + ekstra;
        return netMaas;
    }

    // --- Yardımcı metod ---
    public double getSskOrani() {
        double oran = 0.15;

        // Şart: Hamile + Çocuk 3 aydan büyük + Kız çocuğu
        if (hamilelikDurumu && bebekAylık > 3 && cocukCinsiyet == Cinsiyet.KADIN) {
            oran = 0.13;
        }

        return oran;
    }

    // Getter’lar
    public int getBrutMaas() { return brutMaas; }
    public int getAvans() { return avans; }
    public double getSskPrim() { return sskPrim; }
    public double getGelirVergisi() { return gelirVergisi; }
    public double getNetMaas() { return netMaas; }
    public Cinsiyet getCinsiyet() { return cinsiyet; }
    public boolean isHamilelikDurumu() { return hamilelikDurumu; }
    public Cinsiyet getCocukCinsiyet() { return cocukCinsiyet; }
    public int getCocukAylık() { return bebekAylık; }
}
